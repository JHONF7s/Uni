#include <stdio.h>

int main(void){
	int numero = 5;
    if (numero > 5){
        printf("hola señores");
        return 0;
    }
    printf("mama es mi mama\n");
    return 0;
} //hola desde el celular 


//me gusto mi inventó hello