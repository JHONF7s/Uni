int main(){
    int numero;
    if (numero > 5){
        printf("si);
    }
}