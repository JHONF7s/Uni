#include <stdio.h>

int main(){
    int numero = 5;
    return 0;
}