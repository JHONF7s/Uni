/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author admin
 */
public class CalculoNumero {
    private int numeroUno;
    private int numeroDos;
    
    
    public CalculoNumero(int numeroUno, int numeroDos){
        this.numeroUno = numeroUno;
        this.numeroDos = numeroDos;
    }
    
    public int getNumeroUno(){return numeroUno;}
    public int getNumeroDos(){return numeroDos;}
    
}
