package controladores;
import modelo.Persona;

public class ControladorPersona {
    
    private Persona personas[];

    public ControladorPersona(){
        this.personas = new Persona[1];
    }
    
     private int buscarIndicePersona(int id){
        for (int i = 0; i < personas.length; i++){
            if (personas[i] != null && personas[i].getId() == id){
                return i;
            }
        }
        return -1;
    }        
    

    public boolean guardarPersona(Persona persona){
        for (int i = 0; i < personas.length; i++){
            if (personas[i] == null){
                personas[i] = persona;
                return true;
            }
        }
        return false;
    }

    public Persona buscarPersona(int id){
       int indice = buscarIndicePersona(id);
       if (indice >= 0){
           return personas[indice];
       }
       return null;
    }
    
    public boolean eliminarPersonaPorId(int id){
        int indice = buscarIndicePersona(id);
        if (indice >= 0){
            personas[indice] = null;
            return true;   
        }
        return false;
    }
    
    public boolean editarPersona(int id, String nombre, int edad){
        int indice = buscarIndicePersona(id); 
        if (indice >= 0){
            personas[indice].setEdad(edad);
            personas[indice].setNombre(nombre);
            return true;
        }
        return false;
    }
    
    
    public boolean editarPersona(int id, int edad){
        int indice = buscarIndicePersona(id); 
        if (indice >= 0){
            personas[indice].setEdad(edad);
            return true;
        }
        return false;
    }
    
    
    public boolean editarPersona(int id, String nombre){
        int indice = buscarIndicePersona(id); 
        if (indice >= 0){
            personas[indice].setNombre(nombre);
            return true;
        }
        return false;
    }

}