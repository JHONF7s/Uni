/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author admin
 */
public class Curso {
    private String id;
    private String nombre;
    private double notas[] = new double[3];

    public Curso(String id, String nombre) {
        this.id = id;
        this.nombre = nombre;
    }
    
    
    
}
